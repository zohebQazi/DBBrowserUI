﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Itecx.Util.Chooser
{
    class PARTYChooserForm : ChooserForm
    {
        public PARTYChooserForm() : base("TBL_PARTY","ÏD")
        {
        }
    }
}
